
public class ConsoleScoreBoard extends ScoreBoard{
	int maxNameLength;
	
	public ConsoleScoreBoard(Player[] players) {
		super(players);
		determineMaxNameLength();
	}
	
	public ConsoleScoreBoard(String gameData, Player[] players) {
		super(players);
		determineMaxNameLength();
	}

	@Override
	public void update(){
		for (int i = 0; i < players.length; i++){
			tab();
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			tab(); 
			printIndividualThrows(players[i].score.individualThrows);
			System.out.print(players[i].name);
			for (int spaceNumber = players[i].name.length(); spaceNumber < maxNameLength + 3; spaceNumber++){
				System.out.print(" ");
			}
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			tab();
			printCumulativeFrameScores(players[i].score.cumulativeFrameScores);
			tab();
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			System.out.println("");
		}
	}

	private void tab() {
		for (int spaceNumber = 0; spaceNumber < maxNameLength + 3; spaceNumber++){
			System.out.print(" ");
		}		
	}
	
	public void printIndividualThrows(int[] individualThrows) {
		String data = "|";
		for (int throwIndex = 0; throwIndex < 18; throwIndex++){
			if (throwIndex % 2 == 0){
				if (individualThrows[throwIndex] == 10){
					data += "   | X |";
					throwIndex++;
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			} else {
				if (individualThrows[throwIndex] + individualThrows[throwIndex-1] == 10){
					data += " / |";
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			}
		}
		for (int throwIndex = 18; throwIndex < 21; throwIndex++){
			if (individualThrows[throwIndex] == 10){
				data += " X |";
			} else if (throwIndex != 18){
				if (individualThrows[throwIndex] != 0 & individualThrows[throwIndex] + individualThrows[throwIndex -1] == 10){
					data += " / |";
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			} else {
				data += " ";
				data += individualThrows[throwIndex];
				data += " |";
			}
		}
		System.out.println(data);
	}

	public void printCumulativeFrameScores(int[] cumulativeFrameScores) {
		String data = "|";
		for (int frame = 1; frame < 10; frame++){// Standard conditions apply
			if (cumulativeFrameScores[frame-1] < 10){
				data += "   ";
				data += cumulativeFrameScores[frame-1];
				data += "   |";
			}else if (cumulativeFrameScores[frame-1] < 100) {
				data += "  ";
				data += cumulativeFrameScores[frame-1];
				data += "   |";
			} else{
				data += "  ";
				data += cumulativeFrameScores[frame-1];
				data += "  |";
			}
		}
		if (cumulativeFrameScores[9] < 10){
			data += "     ";
			data += cumulativeFrameScores[9];
			data += "     |";
		}else if (cumulativeFrameScores[9] < 10) {
			data += "    ";
			data += cumulativeFrameScores[9];
			data += "     |";
		} else {
			data += "    ";
			data += cumulativeFrameScores[9];
			data += "    |";
		}
		System.out.println(data);

	}

	private void determineMaxNameLength() {
		maxNameLength = 0;
		for (int i = 0; i < players.length; i++){
			if (players[i].name.length() > maxNameLength){
				maxNameLength = players[i].name.length();
			}
		}

	}

	
	
}
