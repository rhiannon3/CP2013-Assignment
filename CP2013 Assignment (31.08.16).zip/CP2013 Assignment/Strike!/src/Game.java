import java.util.Scanner;

public class Game {
	// Declare the variables required for both loaded and saved games
	Player[] players;
	int pinsKnockedDown;
	private static Scanner userInput;
	ConsoleScoreBoard scoreBoard;
	private int numberOfPlayers;

	// Declare the variables required 
	boolean resumedGame;
	int initialPlayerIndexUponLoad;
	boolean playerHasMadeThrowUponLoad;
	int initialFrameUponLoad;


	// This is the constructor for loading a previous games data
	public Game(String gameData) {
		/*
		 * The string gameData will have the following format:
		 * "initialFrameUponLoad:initialPlayerIndexUponLoad:playerHasMadeThrowUponLoad:numberOfPlayers:playersData,"
		 * The string playersData will have the following format:
		 * "individualPlayerData1,individualPlayerData2,individualPlayerData3" etc. 
		 * The string individualPlayerData will have the following format:
		 * "name;scoreData"
		 */
		//
		String playersData = "";
		String.format(gameData, "%i:%i:%b:%i:%s,", initialFrameUponLoad, initialPlayerIndexUponLoad, playerHasMadeThrowUponLoad, numberOfPlayers, playersData);
		players = new Player[numberOfPlayers]; 
		String[] playersDataArray = playersData.split(",");
		for (int i = 0; i < numberOfPlayers; i++ ){
			String[] individualPlayerData = playersDataArray[i].split(";");
			players[i] = new Player(individualPlayerData);
		}
		scoreBoard = new ConsoleScoreBoard(players);
		scoreBoard.update();
		resumedGame = true;
		play();
	}

	// This is the constructor for creating a new game
	public Game(String[] playerNames) {
		initialPlayerIndexUponLoad = 0;
		initialFrameUponLoad = 1;
		players = new Player[playerNames.length];
		for (int i = 0; i < playerNames.length; i++){
			players[i] = new Player(playerNames[i]);
		}
		scoreBoard = new ConsoleScoreBoard(players);
		resumedGame = false;
		play();
	}

	private void play(){
		// Set up the scanner object for a console based app
		userInput = new Scanner(System.in);

		System.out.println("");
		System.out.println("Let the Game Begin!");

		for (int frame = initialFrameUponLoad; frame <= 10; frame++) {
			System.out.println("");
			System.out.print("Frame ");
			System.out.print(frame);
			System.out.println(":");
			if (resumedGame){
				if (playerHasMadeThrowUponLoad){
					// Let this player take the 2nd throw to complete their frame
					playerThrow(initialPlayerIndexUponLoad);
					initialPlayerIndexUponLoad++;
				}
			}
			for (int playerIndex = initialPlayerIndexUponLoad; playerIndex < players.length; playerIndex++){
				playerThrow(playerIndex);				
				if (frame != 10){ // The user has a maximum of 2 throws
					if (pinsKnockedDown != 10){
						playerThrow(playerIndex);
					}
				} else { // The user has a maximum of 3 throws
					int throw1Result = pinsKnockedDown;
					playerThrow(playerIndex);
					if (throw1Result + pinsKnockedDown >= 10){ // The player gets the 3rd throw
						playerThrow(playerIndex);
					}
				}
			}
		}
		System.out.println("");
		System.out.println("Game Over");
	}

	private void playerThrow(int playerIndex){
		System.out.println("");
		System.out.print("Enter the number of pins knocked down by ");
		System.out.println(players[playerIndex].name);
		System.out.print(">>> ");
		pinsKnockedDown = userInput.nextInt();
		players[playerIndex].score.update(pinsKnockedDown);
		scoreBoard.update();

	}

	public String save(){
		/*
		 * The string gameData will have the following format:
		 * "initialFrameUponLoad:initialPlayerIndexUponLoad:playerHasMadeThrowUponLoad:numberOfPlayers:playersData,"
		 * The string playersData will have the following format:
		 * "individualPlayerData1,individualPlayerData2,individualPlayerData3" etc. 
		 * The string individualPlayerData will have the following format:
		 * "name;scoreData"
		 */
		String gameData = "";
		gameData += String.format("%i:%i:%b::%i:", initialFrameUponLoad, initialPlayerIndexUponLoad, initialPlayerIndexUponLoad, players.length);
		String playersData = "";
		for (int i = 0; i < numberOfPlayers; i++){
			playersData += players[i].name;
			playersData += ";";
			playersData += players[i].score.toString();
			playersData += ",";
		}
		gameData += playersData;
		return gameData;
	}
	
	public void quit(){
		// TODO implement functionality
	}
}
