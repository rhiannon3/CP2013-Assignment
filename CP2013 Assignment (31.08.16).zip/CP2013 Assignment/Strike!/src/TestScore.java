import static org.junit.Assert.*;

import org.junit.Test;

public class TestScore {
	// Define the score Object
	Score score;

	@Test
	public void test() {
		testScore0();
		testScore300();
		testScore299();
		testScore125();
		testScore158();
	}

	private void testScore158() {
		//int [] individualThrows158 = {0, 10, 10, 0, 10, 0, 10, 0, 1, 4, 5, 5, 10, 0, 2, 7, 3, 0, 10, 2, 4};
		// Create mockScore
		MockScore158 mockScore = new MockScore158();

		// Create the score object and fill in the data
		Score score = new Score();
		score.update(0);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(1);
		score.update(4);
		score.update(5);
		score.update(5);
		score.update(10);
		score.update(2);
		score.update(7);
		score.update(3);
		score.update(0);
		score.update(10);
		score.update(2);
		score.update(4);
		
		// Check to see if score is finalized
		if (!score.isFinalised){
			fail();
		}

		// Compare mockScore and Score
		compare(mockScore, score);
	}

	public void testScore0(){
		// Create mockScore
		MockScore0 mockScore = new MockScore0();

		// Create the score object and fill in the data
		Score score = new Score();
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);
		score.update(0);

		// Check to see if score is finalized
		if (!score.isFinalised){
			fail();
		}

		// Compare mockScore and Score
		compare(mockScore, score);

	}

	public void testScore300(){
		// Create mockScore
		MockScore300 mockScore = new MockScore300();

		// Create the score object and fill in the data
		Score score = new Score();
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);

		// Check to see if score is finalized
		if (!score.isFinalised){
			fail();
		}

		// Compare mockScore and Score
		compare(mockScore, score);


	}

	public void testScore299(){
		// Create mockScore
		MockScore299 mockScore = new MockScore299();

		// Create the score object and fill in the data
		Score score = new Score();
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(10);
		score.update(9);

		// Check to see if score is finalized
		if (!score.isFinalised){
			fail();
		}

		// Compare mockScore and Score
		compare(mockScore, score);


	}

	public void testScore125(){
		// Create mockScore
		MockScore125 mockScore = new MockScore125();

		// Create the score object and fill in the data
		Score score = new Score();
		//		int [] individualThrows125 = {2, 5, 10, 0, 5, 1, 0, 0, 3, 0, 5, 5, 10, 0, 7, 3, 3, 7, 10, 10, 0};
		score.update(2);
		score.update(5);
		score.update(10);
		score.update(5);
		score.update(1);
		score.update(0);
		score.update(0);
		score.update(3);
		score.update(0);
		score.update(5);
		score.update(5);
		score.update(10);
		score.update(7);
		score.update(3);
		score.update(3);
		score.update(7);
		score.update(10);
		score.update(10);
		score.update(0);

		// Check to see if score is finalized
		if (!score.isFinalised){
			fail();
		}

		// Compare mockScore and Score
		compare(mockScore, score);

	}


	public void compare(Score mockScore, Score score){
		// Compare individualThrows array
		for (int i = 0; i < 21; i++){
			if (mockScore.individualThrows[i] != score.individualThrows[i]){
				fail();
			}
		}

		// Compare cumulativeFrameScores array
		for (int i = 0; i < 10; i++){
			if (mockScore.cumulativeFrameScores[i] != score.cumulativeFrameScores[i]){
				fail();
			}
		}
	}


}
