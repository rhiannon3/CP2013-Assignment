import java.io.IOException;

public class ScoreBoard {
	Player[] players;
	char[][] scoreCharacters;


	// This is the constructor for creating a new game 
	public ScoreBoard(Player[] players) {
		// TODO Auto-generated constructor stub
		this.players = players;
		scoreCharacters = new char[players.length][2];
	}


	public void update() {
		// TODO Auto-generated method stub
		
	}
	

}
