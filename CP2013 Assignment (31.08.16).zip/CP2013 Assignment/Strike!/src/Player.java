
public class Player {
	String name;
	Score score;

	public Player(String name) {
		// TODO Implement Functionality
		this.name = name;
		score = new Score();
	}
	
	public Player (String[] individualPlayerData){
		name = individualPlayerData[0];
		score = new Score(individualPlayerData[1]);
	}

}
