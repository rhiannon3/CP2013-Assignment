public class Score {
	// Declare the variables
	public int[] individualThrows;
	public int[] cumulativeFrameScores;
	public int cumulativeScore;
	public boolean isFinalised;
	private int completedFrames;
	private int scoredFrames;
	private int throwsMade;
	private boolean calculateSingleStrikeOfFrame9;

	// Define the conditions
	private String queuedFrameCondition;
	private static final String STANDARD = "Standard";
	private static final String SINGLESTRIKE = "SingleStrike";
	private static final String DOUBLESTRIKE = "DoubleStrike";
	private static final String TRIPLESTRIKE = "TripleStrike";
	private static final String SPARE = "Spare";
	private static final String BONUSTHROW = "BonusThrow";

	// Create the constructor
	public Score(){
		individualThrows = new int[21];
		cumulativeFrameScores = new int[10];
		cumulativeScore = 0;
		completedFrames = 0;
		scoredFrames = 0;
		throwsMade = 0;
		isFinalised = false;
		queuedFrameCondition = STANDARD;
		calculateSingleStrikeOfFrame9 = false;
	}

	public Score(String loadedScoreData) {
		// TODO Auto-generated constructor stub
	}

	// Create the method to update the score
	public void update (int pinsKnockedDown){
		// Add pinsKnockedDown to throwsMade
		individualThrows[throwsMade] = pinsKnockedDown;
		throwsMade++;
		// Check if special conditions apply because 
		// the throw made was in Frame 10
		if (throwsMade <= 18){ // Frames 1-9: no special conditions apply
			// Check for a strike
			if (pinsKnockedDown == 10){ 
				// 10 pins were knocked down for the throw
				if (throwsMade % 2 == 1){
					// These pins were knocked down on the 1st throw of the frame
					individualThrows[throwsMade] = 0;
					throwsMade++;
				}
			}
		} else if (throwsMade == 20){
			// Check if the game is finished or if the user gets
			// the bonus throw
			if (individualThrows[18] + individualThrows[19] < 10){
				isFinalised = true;
			}
		} 
		checkFrameCanBeScored();
	}

	// Create the method that will check after which throws cumulativeFrameScores 
	// and cumulativeScore need to be calculated
	private void checkFrameCanBeScored() {
		if (throwsMade <= 18){ // Frames 1-9: no special conditions apply
			switch(queuedFrameCondition){
			case STANDARD:
				// Calculate a standard frame after the frame is completed
				if (throwsMade % 2 == 0){// Throw 2 of the most recent frame has been made
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){ // Neither a spare or strike was thrown
						calculateFrame(STANDARD);
						// Note that queuedFrameCondition does not change	
						queuedFrameCondition = STANDARD;
					} else if (individualThrows[throwsMade-2] == 10){ // A strike was thrown
						// Another frame is now required to calculate the score of this frame
						queuedFrameCondition= SINGLESTRIKE;
					} else { // A spare was thrown
						// Another frame is now required to calculate the score of this frame
						queuedFrameCondition = SPARE;
					}
				}			
				break;
			case SPARE:
				// Calculate a spare frame after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A strike was thrown
					calculateFrame(SPARE);
					queuedFrameCondition = SINGLESTRIKE;				
				} else { // Either a standard frame or a spare will be thrown
					calculateFrame(SPARE);
					// If a spare is thrown it will be detected after throw 2 is made
					queuedFrameCondition = STANDARD;				
				}			
				break;
			case SINGLESTRIKE:
				// Calculate a single strike after the next frame is completed
				if (throwsMade % 2 == 0){
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){
						// Condition 1: The single strike is followed by a standard frame
						calculateFrame(SINGLESTRIKE);
						queuedFrameCondition = STANDARD;
						calculateFrame(STANDARD);
					} else if (individualThrows[throwsMade-2] == 10){
						// Condition 2: The single strike is followed by another strike
						queuedFrameCondition = DOUBLESTRIKE;
					} else {
						// Condition 3: The single strike is followed by spare
						calculateFrame(SINGLESTRIKE);
						queuedFrameCondition = SPARE;
					}
				}			
				break;
			case DOUBLESTRIKE:
				// Calculate a double strike after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A triple strike was achieved
					calculateFrame(TRIPLESTRIKE);
					// Note that queuedFrameCondition does not change
					queuedFrameCondition = DOUBLESTRIKE;				
				} else { 
					calculateFrame(DOUBLESTRIKE);
					queuedFrameCondition = SINGLESTRIKE;
				}
				break;
			}
		} else if (throwsMade == 19){ // Frame 10, Throw 1
			// Special Conditions Apply
			switch(queuedFrameCondition){
			case STANDARD:
				// The STANDARD case can only be followed by a single strike or a standard case
				if (individualThrows[throwsMade -1] == 10){
					queuedFrameCondition = SINGLESTRIKE;
				} else {
					queuedFrameCondition = STANDARD;
				}
				break;
			case SPARE:
				calculateFrame(SPARE);
				// The SPARE case can only be followed by a single strike or a standard case
				if (individualThrows[throwsMade -1] == 10){
					queuedFrameCondition = SINGLESTRIKE;
				} else {
					queuedFrameCondition = STANDARD;
				}
				break;
			case SINGLESTRIKE:
				// THE SINGLESTRIKE can be followed by a standard or double strike
				calculateSingleStrikeOfFrame9 = true;
				if (individualThrows[throwsMade - 1] == 10){
					queuedFrameCondition = DOUBLESTRIKE;
				} else {
					queuedFrameCondition = STANDARD;
				}

				break;
			case DOUBLESTRIKE:
				if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
					calculateFrame(TRIPLESTRIKE);
					// Note that queuedFrameCondition does not change
					queuedFrameCondition = DOUBLESTRIKE;				
				} else { 
					calculateFrame(DOUBLESTRIKE);
					queuedFrameCondition = SINGLESTRIKE;
				}
				break;
			}
		} else if (throwsMade == 20){ // Frame 10, Throw 2
			// Special Conditions Apply
			if (calculateSingleStrikeOfFrame9){
				calculateFrame(SINGLESTRIKE);
			}
			switch(queuedFrameCondition){
			case STANDARD:
				// A Standard may be followed by either be a standard or a spare
				if (individualThrows[18] + individualThrows[19] == 10){
					queuedFrameCondition = SPARE;
				} else {
					calculateFrame(STANDARD);
				}
				break;
			case SINGLESTRIKE:
				if (individualThrows[19] == 10){
					queuedFrameCondition = DOUBLESTRIKE;
				}
				break;
			case DOUBLESTRIKE:
				if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
					calculateFrame(TRIPLESTRIKE);
					// Note that queuedFrameCondition does not change
					queuedFrameCondition = DOUBLESTRIKE;				
				} else { 
					calculateFrame(DOUBLESTRIKE);
					queuedFrameCondition = SINGLESTRIKE;
				}
				break;
			}
		} else { // The player has received the bonus throw
			calculateFrame(BONUSTHROW);
		}

	}

	private void calculateFrame(String condition) {
			int mostRecentThrow = throwsMade - 1;
			switch(condition){
			case STANDARD:
				cumulativeScore += individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
				break;
			case SPARE:
				if (throwsMade % 2 == 0){ // The spare was followed by a strike
					cumulativeScore += 20;
				} else {
					cumulativeScore += 10 + individualThrows[mostRecentThrow];
				}
				break;
			case SINGLESTRIKE:
				cumulativeScore += 10 + individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
				break;
			case DOUBLESTRIKE:
				cumulativeScore += 20 + individualThrows[mostRecentThrow];
				break;
			case TRIPLESTRIKE:
				cumulativeScore += 30;
				break;
			case BONUSTHROW:
				cumulativeScore += individualThrows[18] + individualThrows[19] + individualThrows[20];
				break;
			}
			cumulativeFrameScores[scoredFrames] = cumulativeScore;
			scoredFrames++;	
			if (scoredFrames == 10){
				isFinalised = true;
			}
	}

	@Override
	public String toString(){
		String scoreData = "";
		return scoreData;
	}
}