
public class MockScore0 extends Score {
	
	public MockScore0 () {
		individualThrows[0] = 0;
		individualThrows[1] = 0;
		individualThrows[2] = 0;
		individualThrows[3] = 0;
		individualThrows[4] = 0;
		individualThrows[5] = 0;
		individualThrows[6] = 0;
		individualThrows[7] = 0;
		individualThrows[8] = 0;
		individualThrows[9] = 0;
		individualThrows[10] = 0;
		individualThrows[11] = 0;
		individualThrows[12] = 0;
		individualThrows[13] = 0;
		individualThrows[14] = 0;
		individualThrows[15] = 0;
		individualThrows[16] = 0;
		individualThrows[17] = 0;
		individualThrows[18] = 0;
		individualThrows[19] = 0;
		individualThrows[20] = 0;
		
		cumulativeFrameScores[0] = 0;
		cumulativeFrameScores[1] = 0;
		cumulativeFrameScores[2] = 0;
		cumulativeFrameScores[3] = 0;
		cumulativeFrameScores[4] = 0;
		cumulativeFrameScores[5] = 0;
		cumulativeFrameScores[6] = 0;
		cumulativeFrameScores[7] = 0;
		cumulativeFrameScores[8] = 0;
		cumulativeFrameScores[9] = 0;
	}
}
