import java.util.Scanner;

public class App {
	private static Scanner userInput;
	private static Game game;

	public static void main(String[] args) {
		// Set up the scanner object for a console based app
		userInput = new Scanner(System.in);
		
		// Set up the welcome message
		System.out.println("Strike!");
		System.out.println("Bowling Scores Calculator");
		System.out.println("");
		System.out.println("1. Start New Game");
		System.out.println("2. Load Game");
		System.out.print(">>> ");
		
		int gameSelection = userInput.nextInt();
		
		if (gameSelection == 1){
			startNewGame();
		} else {
			loadGame();
		}
		

	}
	
	private static void startNewGame(){
		System.out.println("");
		System.out.println("Select the number of players: ");
		System.out.print(">>> ");
		
		int numberOfPlayers = userInput.nextInt();
		String[] playerNames = new String[numberOfPlayers];
		for (int i = 0; i < numberOfPlayers; i++){
			System.out.println("");
			System.out.print("Enter Player ");
			System.out.print(i + 1);
			System.out.println("'s name:");
			System.out.print(">>> ");
			userInput.reset();
			playerNames[i] = userInput.next();
		}
		game = new Game(playerNames);
	}
	
	private static void loadGame(){
		// TODO implement code to interact with MySQL Database
//		String gameData = "";  // some functionality
//		game = new Game(gameData);
//		
	}

}
