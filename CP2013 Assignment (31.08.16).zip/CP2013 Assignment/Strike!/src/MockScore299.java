
public class MockScore299 extends Score {

	public MockScore299() {
		individualThrows[0] = 10;
		individualThrows[1] = 0;
		individualThrows[2] = 10;
		individualThrows[3] = 0;
		individualThrows[4] = 10;
		individualThrows[5] = 0;
		individualThrows[6] = 10;
		individualThrows[7] = 0;
		individualThrows[8] = 10;
		individualThrows[9] = 0;
		individualThrows[10] = 10;
		individualThrows[11] = 0;
		individualThrows[12] = 10;
		individualThrows[13] = 0;
		individualThrows[14] = 10;
		individualThrows[15] = 0;
		individualThrows[16] = 10;
		individualThrows[17] = 0;
		individualThrows[18] = 10;
		individualThrows[19] = 10;
		individualThrows[20] = 9;
		
		cumulativeFrameScores[0] = 30;
		cumulativeFrameScores[1] = 60;
		cumulativeFrameScores[2] = 90;
		cumulativeFrameScores[3] = 120;
		cumulativeFrameScores[4] = 150;
		cumulativeFrameScores[5] = 180;
		cumulativeFrameScores[6] = 210;
		cumulativeFrameScores[7] = 240;
		cumulativeFrameScores[8] = 270;
		cumulativeFrameScores[9] = 299;
	}

	
}
