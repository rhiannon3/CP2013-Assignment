import java.awt.event.ActionEvent;

public class GUIGame {
	private static Player[] players;
	private static ScoreBoardGUI scoreBoard;
	private static int pinsKnockedDown;
	private static Player currentPlayer;
	private static int playerNumber;
	private static int throwsTaken; 
	
	
	public GUIGame(int numberOfPlayers){
		players = new Player[numberOfPlayers];
		// TODO get the player names
		ScoreBoardGUI scoreBoard = new ScoreBoardGUI(players);
		
		// Set up the GUI
		
		// Set the initial variables
		throwsTaken = 0;
		playerNumber = 0;
		currentPlayer = players[playerNumber];
		
	}
	
	private static ActionAdapter buttonHandler = new ActionAdapter(){
		public void actionPerformed(ActionEvent e){
			// Respond to the users input
			if (scoreBoard.gameComplete() == false){
				InputButton clickedButton = (InputButton) e.getSource();
				pinsKnockedDown = clickedButton.getValue();
				currentPlayer.score.update(pinsKnockedDown);
				scoreBoard.update();
				// TODO implement functionality to disable buttons so that a user can not get
				// a total of more than 10 pins knocked down for frames 1-9. 
				if (pinsKnockedDown == 10){
					throwsTaken += 2;
				} else {
					throwsTaken++;
				}
				if (throwsTaken == 2){
					playerNumber++;
					updatePlayer();
				}
			} else {
				// Some implementation to communicate to the user that the game is finished
			}
		}

		private void updatePlayer() {
			if (playerNumber == players.length){
				playerNumber = 0;
			}
			currentPlayer = players[playerNumber];			
		}

	};

	
	// Create a function that responds to the input buttons being clicked
	

}
