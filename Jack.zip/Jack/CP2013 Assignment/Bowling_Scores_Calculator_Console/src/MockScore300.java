

public class MockScore300 extends Score{
	int index;
	int frame;
	public MockScore300(){
		// Fill indvidualThrows 
		index = 0;
		for (frame = 1; frame <= 10; frame++){
			if (frame == 10){
				individualThrows[18] = 10;
				individualThrows[19] = 10;
				individualThrows[20] = 10;
			} else {
				individualThrows[2*index] = 10;
				individualThrows[2*index + 1] = 0;
			}
			cumulativeFrameScores[index] = frame*30;
			index++;			
		}
		// Set cumulativeScroe
		cumulativeScore = 300;
	}

}
