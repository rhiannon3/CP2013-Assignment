import javax.swing.JTable;

public class ScoreBoardGUI extends JTable {
	// TODO potentially change JTable to some other object,
	// whatever will make the display of scores as nice as possible
	// Note: The grid that displays the scores will not require any listener. Buttons with 
	//       listeners will be implemented. 	
	private int numberOfPlayers;
	public boolean gameComplete;
	
	// TODO create some variables for tracking which cells are already filled
	public ScoreBoardGUI (Player[] players){
		numberOfPlayers = players.length;
		gameComplete = false;
		// Use players to obtain each player name and 
		// Set up the table grid into the form
		/*        +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
		 *        |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
		 * Name 1 |   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+---+---+---+
		 *        |       |       |       |       |       |       |       |       |       |           |
		 *        +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
		 *        |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
		 * Name 2 |   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+---+---+---+
		 *        |       |       |       |       |       |       |       |       |       |           |
		 *        +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
		 *        |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
		 * Name 3 |   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+   +---+---+---+---+
		 *        |       |       |       |       |       |       |       |       |       |           |
		 *        +-------+-------+-------+-------+-------+-------+-------+-------+-------+-----------+
		 */
		setVisible(true);
		 
	}
	
	public void update(){
		// TODO Update the ScoreBoard
		// Access data from players 
		// eg. setValueAt(arg0, arg1, arg2), where is the input,
		// and arg1 and arg2 are related to the row and column indexes
		if (/* All cells in table are filled*/false){
			gameComplete = true;
		}
		
	}
	

	public boolean gameComplete() {
		return gameComplete;
	}

}
