
public class Player {
	// Declare the variables
	public static String name;
	public Score score;
	
	// Create the constructor method
	public Player(String name){
		this.name = name;
		score = new Score();
	}
	
	public boolean getsBonusThrow(){
		if (score.isFinalised){
			return true;
		} else {
			return false;
		}
	}
}
