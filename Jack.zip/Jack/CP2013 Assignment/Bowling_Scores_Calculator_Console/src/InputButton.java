import java.awt.Button;

public class InputButton extends Button {
	public int value;
	
	public InputButton(int value){
		this.value = value;
	}

	public int getValue() {
		// TODO Auto-generated method stub
		return value;
	}
}
