

public class MockScore2 extends Score{
	// Note: MockScore2 is characterized by a single strike being thrown in frame 10,
	//       a single strike in frame 1 and a spare in frame 2 
	// individualThrows = [];
	// cumulativeFrameScores = [];
	// cumulativeScore = ;
	
	public MockScore2(){
		// Enter the individual throws
//		individualThrows[0] = ;
//		individualThrows[1] = ;
//		individualThrows[2] = ;
//		individualThrows[3] = ;
//		individualThrows[4] = ;
//		individualThrows[5] = ;
//		individualThrows[6] = ;
//		individualThrows[7] = ;
//		individualThrows[8] = ;
//		individualThrows[9] = ;
//		individualThrows[10] = ;
//		individualThrows[11] = ;
//		individualThrows[12] = ;
//		individualThrows[13] = ;
//		individualThrows[14] = ;
//		individualThrows[15] = ;
//		individualThrows[16] = ;
//		individualThrows[17] = ;
//		individualThrows[18] = ;
//		individualThrows[19] = ;
//		individualThrows[20] = ;
		
		// Enter the cumulative frame scores
//		cumulativeFrameScores[0] = ;
//		cumulativeFrameScores[1] = ;
//		cumulativeFrameScores[2] = ;
//		cumulativeFrameScores[3] = ;
//		cumulativeFrameScores[4] = ;
//		cumulativeFrameScores[5] = ;
//		cumulativeFrameScores[6] = ;
//		cumulativeFrameScores[7] = ;
//		cumulativeFrameScores[8] = ;
//		cumulativeFrameScores[9] = ;

		
		// Set cumulativeScore
		// cumulativeScore = ;
	}
	
}
