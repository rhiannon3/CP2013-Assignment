
import static org.junit.Assert.*;

import org.junit.Test;

public class TestScore {

	@Test
	public void test() {
		testMockScore1();
		testMockScore2();
		testMockScore3();
		testMockScore300();
					
	}

	private void testMockScore300(){
		// Check if a perfect game is scored correctly
		MockScore300 perfectScore = new MockScore300();
		Score score300 = new Score();
		// Update the throws
		for (int i = 0; i < 12; i++){
			score300.update(10);
		}
		// Check to see if the test failed
		if (perfectScore.cumulativeScore != score300.cumulativeScore){ // The cumulative score is correct
			fail("Variable cumulativeScore for MockScore300 is not correct.");
		} else if (perfectScore.cumulativeFrameScores != score300.cumulativeFrameScores){
			fail("Variable cumulativeFrameScores for MockScore300 is not correct.");
		} else if (perfectScore.individualThrows != score300.individualThrows) {
			fail("Variable individualThrows for MockScore300 is not correct.");
		}
		
	}

	private void testMockScore1(){
		// Check if the case for MockScore1 is scored correctly
		MockScore1 mockScore1 = new MockScore1();
		Score score1 = new Score();
		// Update the throws
		// individualThrows = [];
		// Check to see if the test failed
		if (mockScore1.cumulativeScore != score1.cumulativeScore){ // The cumulative score is correct
			fail("Variable cumulativeScore for MockScore1 is not correct.");
		} else if (mockScore1.cumulativeFrameScores != score1.cumulativeFrameScores){
			fail("Variable cumulativeFrameScores for MockScore1 is not correct.");
		} else if (mockScore1.individualThrows != score1.individualThrows) {
			fail("Variable individualThrows for MockScore1 is not correct.");
		}
	}

	private void testMockScore2(){
		// Check if the case for MockScore2 is scored correctly
		MockScore2 mockScore2 = new MockScore2();
		Score score2 = new Score();
		// Update the throws
		// individualThrows = [];	
		if (mockScore2.cumulativeScore != score2.cumulativeScore){ // The cumulative score is correct
			fail("Variable cumulativeScore for MockScore2 is not correct.");
		} else if (mockScore2.cumulativeFrameScores != score2.cumulativeFrameScores){
			fail("Variable cumulativeFrameScores for MockScore2 is not correct.");
		} else if (mockScore2.individualThrows != score2.individualThrows) {
			fail("Variable individualThrows for MockScore2 is not correct.");
		}
		
	}

	private void testMockScore3(){
		// Check if the case for MockScore3 is scored correctly
		MockScore3 mockScore3 = new MockScore3();
		Score score3 = new Score();
		// Update the throws
		// individualThrows = [];
		if (mockScore3.cumulativeScore != score3.cumulativeScore){ // The cumulative score is correct
			fail("Variable cumulativeScore for MockScore3 is not correct.");
		} else if (mockScore3.cumulativeFrameScores != score3.cumulativeFrameScores){
			fail("Variable cumulativeFrameScores for MockScore3 is not correct.");
		} else if (mockScore3.individualThrows != score3.individualThrows) {
			fail("Variable individualThrows for MockScore3 is not correct.");
		}
	}
}
