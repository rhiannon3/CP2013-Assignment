
public class ConsoleGame {
	private Player[] players;
	private ScoreBoardConsole scoreBoard;
	private int pinsKnockedDown;
	private Player currentPlayer;
	
	public ConsoleGame(int numberOfPlayers) {
		players = new Player[numberOfPlayers];
		// TODO get the player names
		ScoreBoardConsole scoreBoard = new ScoreBoardConsole(players);
		
		// Note: The game-play logic will be implemented differently with the GUI version.
		//       A 'program loop' will not work for the event-oriented nature of the GUI.  
		for (int frame = 1; frame <= 10; frame++){
			for (int playerIndex = 0 ;playerIndex < players.length; playerIndex++){
				currentPlayer = players[playerIndex];
				playerThrow();
				if (frame != 10){ // Check if the player is permitted to take a second throw
					if (pinsKnockedDown != 10){
						playerThrow();
					}
				} else { // Let the player take a second throw
					playerThrow();
					// Check to see if the player is permitted to take the bonus throw
					if (currentPlayer.getsBonusThrow()){
						playerThrow();
					}
				}
			}
		}		
	}

	private void playerThrow(){
		// TODO get the number of pins knocked down
		currentPlayer.score.update(pinsKnockedDown);
		scoreBoard.update();
	}
}
