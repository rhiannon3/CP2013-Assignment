//TODO import some maths support 

public class Score {
	// Declare the variables
	public int[] individualThrows;
	public int[] cumulativeFrameScores;
	public int cumulativeScore;
	public boolean isFinalised;
	private int completedFrames;
	private int scoredFrames;
	private int throwsMade;

	// Define the conditions
	private String queuedFrameCondition;
	private static final String STANDARD = "Standard";
	private static final String SINGLESTRIKE= "SingleStrike";
	private static final String DOUBLESTRIKE= "DoubleStrike";
	private static final String TRIPLESTRIKE= "TripleStrike";
	private static final String SPARE= "Spare";
	private static final String BONUSTHROW= "BonusThrow";


	//  Create the constructor method
	public Score () {
		individualThrows = new int[21];
		cumulativeFrameScores = new int[10];
		cumulativeScore = 0;
		completedFrames = 0;
		scoredFrames = 0;
		throwsMade = 0;
		isFinalised = false;
		queuedFrameCondition = STANDARD;
	}

	// Create the method that updates the scores after each throw
	public void update(int pinsKnockedDown){
		// Add pinsKnockedDown to throwsMade
		individualThrows[throwsMade] = pinsKnockedDown;
		throwsMade++;
		// Check if that frame is completed
		if (completedFrames < 9){
			if (pinsKnockedDown == 10){// Check if the throw was a strike
				individualThrows[throwsMade] = 0;
				throwsMade++;
				completedFrames++;
			} else if (throwsMade % 2 == 0){// Check if 2 throws were made for that frame
				completedFrames++;
			}
		} else {
			if (throwsMade == 21){
				completedFrames++;				
			} else if (individualThrows[18] + individualThrows[19] < 10){
				individualThrows[20] = 0;
				completedFrames++;
			}
		}
		// Check if the game is finished for the player
		if (completedFrames == 10){
			isFinalised = true;
		}
		checkFrameCanBeScored();
	}


	// Create the method that will check after which throws cumulativeFrameScores 
	// and cumulativeScore need to be calculated
	public void checkFrameCanBeScored(){
		String temporaryQueuedFrameCondition = null;
		if (throwsMade == 21){
			calculateFrame(BONUSTHROW);
		} else {
			switch(queuedFrameCondition){
			case STANDARD:
				// Calculate a standard frame after the frame is completed
				if (throwsMade % 2 == 0){// Throw 2 of the most recent frame has been made
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){ // Neither a spare or strike was thrown
						calculateFrame(STANDARD);
						// Note that queuedFrameCondition does not change	
						temporaryQueuedFrameCondition = STANDARD;
					} else if (individualThrows[throwsMade-2] == 10){ // A strike was thrown
						// Another frame is now required to calculate the score of this frame
						temporaryQueuedFrameCondition= SINGLESTRIKE;
					} else { // A spare was thrown
						// Another frame is now required to calculate the score of this frame
						temporaryQueuedFrameCondition = SPARE;
					}
				}			
				break;
			case SPARE:
				// Calculate a spare frame after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A strike was thrown
					calculateFrame(SPARE);
					temporaryQueuedFrameCondition = SINGLESTRIKE;				
				} else { // Either a standard frame or a spare will be thrown
					calculateFrame(SPARE);
					// If a spare is thrown it will be detected after throw 2 is made
					temporaryQueuedFrameCondition = STANDARD;				
				}			
				break;
			case SINGLESTRIKE:
				// Calculate a single strike after the next frame is completed
				if (throwsMade % 2 == 0){
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){
						// Condition 1: The single strike is followed by a standard frame
						calculateFrame(SINGLESTRIKE);
						temporaryQueuedFrameCondition = STANDARD;
					} else if (individualThrows[throwsMade-2] == 10){
						// Condition 2: The single strike is followed by another strike
						temporaryQueuedFrameCondition = DOUBLESTRIKE;
					} else {
						// Condition 3: The single strike is followed by spare
						calculateFrame(SINGLESTRIKE);
						temporaryQueuedFrameCondition = SPARE;
					}
				}			
				break;
			case DOUBLESTRIKE:
				// Calculate a double strike after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A triple strike was achieved
					calculateFrame(TRIPLESTRIKE);
					// Note that queuedFrameCondition does not change
					temporaryQueuedFrameCondition = DOUBLESTRIKE;				
				} else { 
					calculateFrame(DOUBLESTRIKE);
					temporaryQueuedFrameCondition = SINGLESTRIKE;
				}
				break;
			}
			// Update for the new condition
			queuedFrameCondition = temporaryQueuedFrameCondition;
		}
	}

	// Create the method that calculates cumulativeScore and cumulativeFrameScores
	public void calculateFrame(String condition){
		int mostRecentThrow = throwsMade - 1;
		switch(condition){
		case STANDARD:
			cumulativeScore += individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
			break;
		case SPARE:
			if (throwsMade % 2 == 0){ // The spare was followed by a strike
				cumulativeScore += 20;
			} else {
				cumulativeScore += 10 + individualThrows[mostRecentThrow];
			}
			break;
		case SINGLESTRIKE:
			cumulativeScore += 10 + individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
			break;
		case DOUBLESTRIKE:
			cumulativeScore += 20 + individualThrows[mostRecentThrow];
			break;
		case TRIPLESTRIKE:
			cumulativeScore += 30;
			break;
		case BONUSTHROW:
			cumulativeScore += individualThrows[18] + individualThrows[19] + individualThrows[20];
			break;
		}
		cumulativeFrameScores[scoredFrames] = cumulativeScore;
		scoredFrames++;
	}

}
