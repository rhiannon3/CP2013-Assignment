package View;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class SizeDialog extends JDialog {
	private int numberOfRows;
	private int numberOfColumns;
	
	public SizeDialog(int currentNumberOfRows, int currentNumberOfColumns, ActionAdapter okayButtonHandler){
		numberOfRows = currentNumberOfRows;
		numberOfColumns = currentNumberOfColumns;
		// Create the Rows: n Label
		final JLabel rowsLabel = new JLabel(String.format("Rows: %d", numberOfRows));
		// Create the Columns: n Label
		final JLabel columnsLabel = new JLabel(String.format("Columns: %d", numberOfColumns));
		// Set up the number of rows slider
		final JSlider numberOfRowsSlider = new JSlider(4,10);
		numberOfRowsSlider.setValue(numberOfRows);
		numberOfRowsSlider.addChangeListener( new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent arg0) {
				numberOfRows = numberOfRowsSlider.getValue();
				rowsLabel.setText(String.format("Rows: %d", numberOfRows));
			}
		});
		// Set up the columns slider
		final JSlider numberOfColumnsSlider = new JSlider(4, 10);
		numberOfColumnsSlider.setValue(numberOfColumns);
		numberOfColumnsSlider.addChangeListener( new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent arg0) {
				numberOfColumns = numberOfColumnsSlider.getValue();
				columnsLabel.setText(String.format("Columns: %d", numberOfColumns));
			}
		});
		// Set up the okay button
		JButton okayButton = new JButton("Okay");
		okayButton.addActionListener(okayButtonHandler);
		// Add the rows information to the rows JPanel
		JPanel rowsDataPanel = new JPanel();
		rowsDataPanel.add(rowsLabel, BorderLayout.EAST);
		rowsDataPanel.add(numberOfRowsSlider, BorderLayout.WEST);
		// Add the columns information to the columns JPanel
		JPanel columnsDataPanel = new JPanel();
		columnsDataPanel.add(columnsLabel, BorderLayout.EAST);
		columnsDataPanel.add(numberOfColumnsSlider, BorderLayout.WEST);
		// Add the panels and the okay button to the dialog window
		add(rowsDataPanel, BorderLayout.NORTH);
		add(columnsDataPanel, BorderLayout.CENTER);
	    add(okayButton, BorderLayout.SOUTH);
	    // Set the basic settings
	    setSize(300, 120);
	    setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
	}


	public int getNumberOfRows(){
		return numberOfRows;
	}
	
	public int getNumberOfColumns(){
		return numberOfColumns;
	}
}
