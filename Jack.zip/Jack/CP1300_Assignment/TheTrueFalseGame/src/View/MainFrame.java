package View;


import java.awt.Dimension;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class MainFrame extends JFrame{

	public MainFrame(){
		setTitle("The True/False Game");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setMinimumSize(new Dimension(500, 500));
		setLocationRelativeTo(null);
		
	}
	
	public void setWindowSizeToReadText(int numberOfColumns){
		if (numberOfColumns == 10){
			setSize(new Dimension(550, 500));
		} else {
			setSize(new Dimension(500, 500));
		}
	}

}
