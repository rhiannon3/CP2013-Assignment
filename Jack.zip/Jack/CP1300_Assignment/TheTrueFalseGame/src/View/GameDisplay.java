package View;

import java.awt.GridLayout;

import javax.swing.JPanel;


@SuppressWarnings("serial")
public class GameDisplay extends JPanel {
	int numberOfRows;
	int numberOfColumns;
	private CellButton[][] cellGrid;
	private GridLayout cellButtonLayout;
	ActionAdapter gameCellListener;

	public GameDisplay(ActionAdapter gameCellListener){
		this.gameCellListener = gameCellListener;

	}

	public void setUp(int rows, int columns){
		numberOfRows = rows;
		numberOfColumns = columns;
		cellButtonLayout = new GridLayout(numberOfRows, numberOfColumns);
		setLayout(cellButtonLayout);
		cellGrid = new CellButton[numberOfRows][numberOfColumns];

		for (int rowIndex = 0; rowIndex < numberOfRows; rowIndex++){
			for(int columnIndex = 0; columnIndex < numberOfColumns; columnIndex++){
				cellGrid[rowIndex][columnIndex]= new CellButton(rowIndex, columnIndex);
				cellGrid[rowIndex][columnIndex].addActionListener(gameCellListener);
				add(cellGrid[rowIndex][columnIndex]);
			}
		}

	}

	public void uncoverCellButton(int[] coordinates, String[] displayProperties){
		int rowIndex = coordinates[0];
		int columnIndex = coordinates[1];
		cellGrid[rowIndex][columnIndex].uncoverOnceClicked(displayProperties);
	}
	
	public CellButton accessCellButton(int[] coordinates){
		int rowIndex = coordinates[0];
		int columnIndex = coordinates[1];
		return cellGrid[rowIndex][columnIndex];
	}
	
}
