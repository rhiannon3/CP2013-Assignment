package View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public abstract class ActionAdapter extends Object implements ActionListener{
	public ActionAdapter(){
		
	}
	
	public abstract void actionPerformed(ActionEvent ae);

}
