package View;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

@SuppressWarnings("serial")
public class SettingsMenuBar extends JMenuBar{

	public SettingsMenuBar(ActionAdapter menuListener, String initialDifficulty){
		JMenu settingsMenu = new JMenu("Settings");
		JMenu difficultyOptionsMenu = new JMenu("Difficulty");
		JMenuItem size = new JMenuItem("Size");
		JCheckBoxMenuItem easyDifficulty = new JCheckBoxMenuItem("Easy");
		JCheckBoxMenuItem mediumDifficulty = new JCheckBoxMenuItem("Medium");
		JCheckBoxMenuItem hardDifficulty = new JCheckBoxMenuItem("Hard");
		JMenuItem startNewGame = new JMenuItem("Start New Game");
		
		// Add the difficulty options to a levelGroup so that only one item is selected
		ButtonGroup difficultyOptionsList = new ButtonGroup();
		difficultyOptionsList.add(easyDifficulty);
		difficultyOptionsList.add(mediumDifficulty);
		difficultyOptionsList.add(hardDifficulty);
		
		// Select the necessary initial difficulty
		switch(initialDifficulty){
		case "Easy":
			easyDifficulty.setSelected(true);
			break;
		case "Medium":
			mediumDifficulty.setSelected(true);
			break;
		case "Hard":
			hardDifficulty.setSelected(true);
			break;
		}
		
		// Add the menu Listener to the necessary menu items
		size.addActionListener(menuListener);
		easyDifficulty.addActionListener(menuListener);
		mediumDifficulty.addActionListener(menuListener);
		hardDifficulty.addActionListener(menuListener);
		startNewGame.addActionListener(menuListener);
		
		difficultyOptionsMenu.add(easyDifficulty);
		difficultyOptionsMenu.add(mediumDifficulty);
		difficultyOptionsMenu.add(hardDifficulty);
		settingsMenu.add(size);
		settingsMenu.add(difficultyOptionsMenu);
		settingsMenu.add(startNewGame);
		add(settingsMenu);
	}
}
