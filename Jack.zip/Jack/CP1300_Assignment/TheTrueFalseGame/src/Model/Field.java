package Model;

import java.util.Random;

public class Field {

	private int numberOfRows;
	private int numberOfColumns;
	private String difficulty;
	private int [][] referenceField;
	private Cell [][] gameField;
	private static final Random random = new Random();

	public Field(){
		// Create a new Field object for App
	}

	private Cell[][] generateGameField(){
		// Create the board/playing field with a two-dimensional array of Cells
		Cell[][] gameField = new Cell[numberOfRows][numberOfColumns];
		for(int rowIndex = 0; rowIndex < numberOfRows; rowIndex++){
			for(int columnIndex = 0; columnIndex < numberOfColumns; columnIndex++){
				// For each cell:
				// Determine the surrounding number of flags
				int numberOfSurroundingFlags = getNumberOfSurroundingObects(-1, rowIndex, columnIndex);
				// Determine the surrounding number of treasures
				int numberOfSurroundingTreasures = getNumberOfSurroundingObects(1, rowIndex, columnIndex);
				String cellType = "";
				// Determine if the cell is a flag, treasure or empty cell
				switch(referenceField[rowIndex][columnIndex]){
				case -1:
					cellType = "Flag";
					break;
				case 0:
					cellType = "Empty Cell";
					break;
				case 1: 
					cellType = "Treasure";
					break;
				}
				// Create the cell at the appropriate location on the playing field
				// (within the two-dimensional array of cell objects)
				gameField[rowIndex][columnIndex] = new Cell();
				gameField[rowIndex][columnIndex].setProperties(numberOfSurroundingFlags, numberOfSurroundingTreasures, cellType);
			}
		}
		// Return the game field
		return gameField;
	}

	private int[][] generateReferenceField() {
		// Generate a two-dimensional array of integers to represent the reference playing field
		// filled with empty cells (0)
		int [][] referenceField = new int[numberOfRows][numberOfColumns];
		// Initialise the variables for the number of total required flags and treasures 
		int totalRequiredFlags = 0;
		int totalRequiredTreasures = 0;
		// Determine the number of flags and treasures required depending on the level of 
		// difficulty and the size of the playing field
		switch(difficulty){
		case "Easy":
			totalRequiredFlags = (int) Math.ceil(numberOfRows * numberOfColumns * 0.05);
			totalRequiredTreasures = (int) Math.ceil(numberOfRows * numberOfColumns * 0.01);
			break;
		case "Medium":
			totalRequiredFlags = (int) Math.ceil(numberOfRows * numberOfColumns * 0.1);
			totalRequiredTreasures = (int) Math.ceil(numberOfRows * numberOfColumns * 0.05);
			break;
		case "Hard":
			totalRequiredFlags = (int) Math.ceil(numberOfRows * numberOfColumns * 0.2);
			totalRequiredTreasures = (int) Math.ceil(numberOfRows * numberOfColumns * 0.1);
			break;
		}
		int randomRowIndex;
		int randomColumnIndex;
		// Randomly allocate the number of flags (-1) required to empty cells (0) on the
		// reference playing field
		for(int flagsAdded = 0; flagsAdded < totalRequiredFlags; flagsAdded++){
			randomRowIndex = Math.abs(random.nextInt()) % numberOfRows;
			randomColumnIndex = Math.abs(random.nextInt()) % numberOfColumns;
			while(referenceField[randomRowIndex][randomColumnIndex] != 0) {
				randomRowIndex = Math.abs(random.nextInt()) % numberOfRows;
				randomColumnIndex = Math.abs(random.nextInt()) % numberOfColumns;
			}
			referenceField[randomRowIndex][randomColumnIndex] = -1;
		}
		// Randomly allocate the number of treasures (1) required to empty cells (0) on the
		// reference playing field
		for(int treasuresAdded = 0; treasuresAdded < totalRequiredTreasures; treasuresAdded++){
			randomRowIndex = Math.abs(random.nextInt()) % numberOfRows;
			randomColumnIndex = Math.abs(random.nextInt()) % numberOfColumns;
			while(referenceField[randomRowIndex][randomColumnIndex] != 0) {
				randomRowIndex = Math.abs(random.nextInt()) % numberOfRows;
				randomColumnIndex = Math.abs(random.nextInt()) % numberOfColumns;
			}
			referenceField[randomRowIndex][randomColumnIndex] = 1;
		}
		// Return the reference field
		return referenceField;

	}

	public Cell accessGameCell(int [] cellCoordinates){
		Cell selectedCell = gameField[cellCoordinates[0]][cellCoordinates[1]];
		return selectedCell;
	}

	public boolean hasBeenWon(){
		boolean gameIsWon = true;
		checkGameStatusLoop: for (int rowIndex = 0; rowIndex < numberOfRows; rowIndex++){
			for (int columnIndex = 0; columnIndex < numberOfColumns; columnIndex++){
				if (gameField[rowIndex][columnIndex].isCovered()){
					if (gameField[rowIndex][columnIndex].getType() != "Flag"){
						gameIsWon = false;
						break checkGameStatusLoop;
					}
				}
			}
		}
		return gameIsWon;
	}

	private int getNumberOfSurroundingObects(int type, int cellRowIndex, int cellColumnIndex){
		int sumOfSurroundingObjects = 0;
		for (int rowIndex = cellRowIndex -1; rowIndex <= cellRowIndex + 1; rowIndex++){
			if (rowIndex < 0 || rowIndex >= numberOfRows){
				// the indexed 'surrounding cell' is out of bounds
				continue;
			}
			for (int columnIndex = cellColumnIndex -1; columnIndex <= cellColumnIndex + 1; columnIndex++){
				if (columnIndex < 0 || columnIndex >= numberOfColumns){
					// the indexed 'surrounding cell' is out of bounds
					continue;
				} else if ((rowIndex == cellRowIndex) & (columnIndex == cellColumnIndex)){
					// the cell being examined is the cell that the surronding cells are being checked for
					continue;
				} else if (referenceField[rowIndex][columnIndex] == type){
					sumOfSurroundingObjects++;
				}
			}
		}
		return sumOfSurroundingObjects;
	}

	public void display(){
		String separatingLines = "+";
		for (int builtColumns = 1; builtColumns <= numberOfColumns; builtColumns++){
			separatingLines += "-----+";
		}
		System.out.println(separatingLines);
		for (int rowIndex = 0; rowIndex < numberOfRows; rowIndex++){
			System.out.print("|");
			for (int columnIndex = 0; columnIndex < numberOfColumns; columnIndex++){
				if (gameField[rowIndex][columnIndex].isCovered()) {	
					System.out.print("     |");				
				} else {
					System.out.print(" " + gameField[rowIndex][columnIndex].getDisplayText() + " |");
				}
			}
			System.out.println("");
			System.out.println(separatingLines);
		}
	}

	public void uncoverSurroundingGreenCells(int cellRowIndex, int cellColumnIndex){
		gameField[cellRowIndex][cellColumnIndex].uncover();
		for (int rowIndex = cellRowIndex -1; rowIndex <= cellRowIndex + 1; rowIndex++){
			if (rowIndex < 0 || rowIndex >= numberOfRows){
				// the indexed 'surrounding cell' is out of bounds
				continue;
			}
			for (int columnIndex = cellColumnIndex -1; columnIndex <= cellColumnIndex + 1; columnIndex++){
				if (columnIndex < 0 || columnIndex >= numberOfColumns){
					// the indexed 'surrounding cell' is out of bounds
					continue;
				} else if ((rowIndex == cellRowIndex) & (columnIndex == cellColumnIndex)){
					// the cell being examined is the cell that the surrounding cells are being checked for
					continue;
				} else if (gameField[rowIndex][columnIndex].isCovered() == false){
					continue;
				} else if (gameField[rowIndex][columnIndex].getDisplayText() == "0/0"){
					uncoverSurroundingGreenCells(rowIndex, columnIndex);
				}
			}
		}
	}

	public void uncoverAllCoveredCells(){
		for (int rowIndex = 0; rowIndex < numberOfRows; rowIndex++){
			for (int columnIndex = 0; columnIndex < numberOfColumns; columnIndex++){
				if (gameField[rowIndex][columnIndex].isCovered()){
					gameField[rowIndex][columnIndex].uncover();
				}
			}
		}
	}

    public void setUp(int rows, int columns, String difficulty){
    	numberOfRows = rows;
		numberOfColumns = columns;
		this.difficulty = difficulty;
		// Generate the reference field
		referenceField = generateReferenceField();
		// Generate the game field
		gameField = generateGameField();
    }
}

