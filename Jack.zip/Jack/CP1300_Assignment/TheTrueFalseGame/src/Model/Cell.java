package Model;

public class Cell {

	private String type;
	private int surroundingFlags;
	private int surroundingTreasures;
	private String cellText;
	private String cellColour;
	private boolean isCovered;

	public Cell(){
		isCovered = true;
	}

	public void setProperties(int flags, int treasures, String type){
		surroundingFlags = flags;
		surroundingTreasures = treasures;
		this.type = type;
		determineDisplayTextAndColour();
	}

	public void uncover(){
		isCovered = false;
	}

	public boolean isCovered(){
		return isCovered;
	}

	public String getType(){
		return type;
	}

	public String getDisplayText(){
		return cellText;
	}

	public String getDisplayColour(){
		return cellColour;
	}

	private void determineDisplayTextAndColour(){
		// Determine the cell's display text based on the cell type and the number of
		// surrounding flags and treasures.
		switch(type){
		case "Flag":
			cellText = " F ";
			cellColour = "Red";
			break;
		case "Treasure":
			cellText = " T ";
			cellColour = "Blue";
			break;
		case "Empty Cell":
			if ((surroundingFlags == 0) & (surroundingTreasures == 0)){
				cellText = "0/0";
				cellColour = "Green";

			} else {
				cellText = String.format(surroundingFlags + "/" + surroundingTreasures);
				cellColour = "Grey";
			}
			break;		
		}

	}

}
