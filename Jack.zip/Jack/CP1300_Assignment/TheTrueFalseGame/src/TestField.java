import Model.Field;


public class TestField {
	public static void main(String[] args) {
		
		// Test that the flags ratios for an easy level game are correct. 
		Field easyGameField = new Field();
		System.out.println("Easy 10 x 10 game Field");
		easyGameField.setUp(10, 10, "Easy");
		System.out.println("Expected Output: 10 x 10 covered grid.");
		System.out.println("Actual Output:");
		easyGameField.display();
		easyGameField.uncoverAllCoveredCells();
		System.out.println("Expected Output: 10 x 10 fully uncovered grid with 1 true flag and 5 false flags.");
		System.out.println("Actual Output: ");
		easyGameField.display();
		System.out.println(" ");
		
		// Test that the flags ratios for a medium level game are correct. 
		Field mediumGameField = new Field();
		System.out.println("Medium 10 x 10 game Field");
		mediumGameField.setUp(10, 10, "Medium");
		System.out.println("Expected Output: 10 x 10 covered grid.");
		System.out.println("Actual Output:");
		mediumGameField.display();
		mediumGameField.uncoverAllCoveredCells();
		System.out.println("Expected Output: 10 x 10 fully uncovered grid with 5 true flags and 10 false flags.");
		System.out.println("Actual Output: ");
		mediumGameField.display();
		System.out.println(" ");
		
		// Test that the flags ratios for a medium level game are correct. 
		Field hardGameField = new Field();
		System.out.println("Hard 10 x 10 game Field");
		hardGameField.setUp(10, 10, "Hard");
		System.out.println("Expected Output: 10 x 10 covered grid.");
		System.out.println("Actual Output:");
		hardGameField.display();
		hardGameField.uncoverAllCoveredCells();
		System.out.println("Expected Output: 10 x 10 fully uncovered grid with 10 true flags and 20 false flags.");
		System.out.println("Actual Output: ");
		hardGameField.display();
		System.out.println(" ");
		
		// Test that there is always at least 1 flag and 1 treasure for each game field.
		Field smallestPossibleNumberOfFlagsGameField = new Field();
		System.out.println("Game Field to produce the smallest possible number of true flags and false flags.");
		System.out.println("Easy 4 x 4 game Field");
		smallestPossibleNumberOfFlagsGameField.setUp(4, 4, "Easy");
		System.out.println("Expected Output: 4 x 4 covered grid.");
		System.out.println("Actual Output:");
		smallestPossibleNumberOfFlagsGameField.display();
		smallestPossibleNumberOfFlagsGameField.uncoverAllCoveredCells();
		System.out.println("Expected Output: 4 x 4 fully uncovered grid with 1 true flag and 1 false flag.");
		System.out.println("Actual Output: ");
		smallestPossibleNumberOfFlagsGameField.display();
		System.out.println(" ");
		
		// Test that the display text for the uncovered cells is appropriate for that cell type
		Field smallGameField = smallestPossibleNumberOfFlagsGameField;
		System.out.println("Cell Types: ");
		for (int rowIndex = 0; rowIndex < 4; rowIndex++){
			for(int columnIndex = 0; columnIndex < 4; columnIndex++){
				int[] cellCoordinates = {rowIndex, columnIndex};
				System.out.print(smallGameField.accessGameCell(cellCoordinates).getType() + " ");
			}
			System.out.println("");
		}
		System.out.println(" ");
		
		// Test that the display text for the uncovered cells is appropriate for that cell type
		System.out.println("Cell Display Colours: ");
		for (int rowIndex = 0; rowIndex < 4; rowIndex++){
			for(int columnIndex = 0; columnIndex < 4; columnIndex++){
				int[] cellCoordinates = {rowIndex, columnIndex};
				System.out.print(smallGameField.accessGameCell(cellCoordinates).getDisplayColour() + " ");
			}
			System.out.println("");
		}
			
		// Test that the fields are different even if the settings are the same because they are 
		// randomly generated
		
		Field gameField = new Field();
		System.out.println("Game Field to show that Fields are randomly generated.");
		System.out.println("Easy 4 x 4 game Field");
		gameField.setUp(4, 4, "Easy");
		System.out.println("Expected Output: 4 x 4 covered grid.");
		System.out.println("Actual Output:");
		gameField.display();
		gameField.uncoverAllCoveredCells();
		System.out.println("Expected Output: 4 x 4 fully uncovered grid with 1 true flag and 1 false flag,");
	    System.out.println("with a different layout to the previous field with the same settings.");
		System.out.println("Actual Output: ");
		gameField.display();
		System.out.println(" ");
		
	
	
	}

}
