
import java.awt.event.ActionEvent;

import javax.swing.JDialog;
import javax.swing.JLabel;

public class App {
	private static final String EASY = "Easy";
	private static final String MEDIUM = "Medium";
	private static final String HARD = "Hard";
	private static final String SIZE = "Size";
	private static final String STARTNEWGAME = "Start New Game";
	private static String setDifficulty;
	private static int setNumberOfRows;
	private static int setNumberOfColumns;
	private static boolean gameIsntOver;
	private static Field gameField;
	private static MainFrame mainFrame;
	private static GameDisplay gameDisplay;
	private static SizeDialog sizeDialog; 

	public static void main(String[] args) {
		// Set the default game settings
		setNumberOfRows = 10;
		setNumberOfColumns = 10;
		setDifficulty = "Easy";
		
		// Set up the game GUI
		mainFrame = new MainFrame();
		SettingsMenuBar settings = new SettingsMenuBar(menuListener, setDifficulty);
		mainFrame.setJMenuBar(settings);
		mainFrame.setVisible(true);

		// Set up the Field variable
		gameField = new Field();
		
		// Start a new game
		startNewGame();

	}

	// Add the listener for the menu items
	private static ActionAdapter menuListener = new ActionAdapter() {

		public void actionPerformed(ActionEvent e) {
			switch (e.getActionCommand()) {
			case EASY:
				setDifficulty = EASY;
				mainFrame.remove(gameDisplay);
				startNewGame();
				break;
			case MEDIUM:
				setDifficulty = MEDIUM;
				mainFrame.remove(gameDisplay);
				startNewGame();
				break;
			case HARD:
				setDifficulty = HARD;
				mainFrame.remove(gameDisplay);
				startNewGame();
				break;
			case SIZE:
				sizeDialog = new SizeDialog(setNumberOfRows, setNumberOfColumns, okayButtonHandler);
				break;
			case STARTNEWGAME:
				mainFrame.remove(gameDisplay);
				startNewGame();
				break;
			} 

		}
	};

	// Add the listener for the cell items
	private static ActionAdapter gameCellHandler = new ActionAdapter(){
		public void actionPerformed(ActionEvent e){
			if (gameIsntOver){
				CellButton clickedCellButton = (CellButton) e.getSource();
				if (clickedCellButton.hasntBeenRevealed()){
				int[] cellCoordinates = new int[2];
				cellCoordinates[0] = clickedCellButton.getRowPosition();
				cellCoordinates[1] = clickedCellButton.getColumnPosition();
				updateGameStatus(cellCoordinates);
				}
			} else {
				JDialog gameLostMessage = new JDialog();
				JLabel messageText = new JLabel("No current game.");
				gameLostMessage.add(messageText);
				gameLostMessage.setLocationRelativeTo(null);
				gameLostMessage.setSize(30, 60);
				gameLostMessage.setVisible(true);
			}
		}

	};

	// Add the listener for the set size button for SizeDialog

	// Add the listener for the okay button on the size dialog
    private static ActionAdapter okayButtonHandler = new ActionAdapter(){
		public void actionPerformed(ActionEvent e){
			setNumberOfRows = sizeDialog.getNumberOfRows();
			setNumberOfColumns = sizeDialog.getNumberOfColumns();
			sizeDialog.dispose();
			mainFrame.remove(gameDisplay);
			startNewGame();
		}

	};

	private static void updateGameStatus(int [] clickedCellCoordinates){
		Cell clickedCell = gameField.accessGameCell(clickedCellCoordinates);
		if (clickedCell.getType() == "Flag") {
			// Code for pop - up message that game is over
			JDialog gameOverWindow = new JDialog();
			JLabel gameOver = new JLabel("Game Over!");
			gameOverWindow.add(gameOver);
			gameOverWindow.setSize(30, 60);
			gameOverWindow.setLocationRelativeTo(null);
			gameOverWindow.setVisible(true);
			gameField.uncoverAllCoveredCells();
			uncoverListOfCells();
			gameIsntOver = false;
		} else if (clickedCell.getDisplayColour() == "Green"){
			// Code to uncover surrounding green cells
			gameField.uncoverSurroundingGreenCells(clickedCellCoordinates[0], clickedCellCoordinates[1]);
			uncoverListOfCells();
		} else {
			String[] displayProperties = getClickedCellDisplayProperties(clickedCell);
			gameDisplay.uncoverCellButton(clickedCellCoordinates, displayProperties);
		}
		if (gameIsntOver){
			if (gameField.hasBeenWon()){
				gameIsntOver = false; 
				// Code for pop - up message that game has been won
				JDialog gameWonWindow = new JDialog();
				JLabel gameWon = new JLabel("You Win!");
				gameWonWindow.add(gameWon);
				gameWonWindow.setSize(30, 60);
				gameWonWindow.setLocationRelativeTo(null);
				gameWonWindow.setVisible(true);
			}
		}
		
	}

	private static String[] getClickedCellDisplayProperties(Cell cellBeingRevealed){
		if (cellBeingRevealed.isCovered()){
		cellBeingRevealed.uncover();
		}
		String[] cellProperties = new String[2];
		cellProperties[0] = cellBeingRevealed.getDisplayText();
		cellProperties[1] = cellBeingRevealed.getDisplayColour();
		return cellProperties;

	}

	private static void uncoverListOfCells(){
		for (int rowIndex = 0; rowIndex < setNumberOfRows; rowIndex++){
			for (int columnIndex = 0; columnIndex < setNumberOfColumns; columnIndex++){
				int [] cellCoordinates = {rowIndex, columnIndex};
				Cell cell = gameField.accessGameCell(cellCoordinates);
				if (cell.isCovered() == false){
					CellButton cellButton = gameDisplay.accessCellButton(cellCoordinates);
					if (cellButton.hasntBeenRevealed()){
						String[] displayProperties = getClickedCellDisplayProperties(cell);
						gameDisplay.uncoverCellButton(cellCoordinates, displayProperties);
					}
				}
			}
		}
	}

    private static void startNewGame(){
		// Set up the game display
		gameDisplay = new GameDisplay(gameCellHandler);
		gameDisplay.setUp(setNumberOfRows, setNumberOfColumns);
		mainFrame.add(gameDisplay);
		mainFrame.pack();
		
		
		// Set up the game Model
		gameIsntOver = true;
		gameField.setUp(setNumberOfRows, setNumberOfColumns, setDifficulty);
		
		// Make sure the user can read the text 
		mainFrame.setWindowSizeToReadText(setNumberOfColumns);
    }
}


