import java.util.Scanner;

public class Game {
	Player[] players;
	int pinsKnockedDown;
	private static Scanner userInput;
	ScoreBoard scoreBoard;
	
	// This is the constructor for loading a previous games data
	public Game(String gameData) {
		// TODO Implement Functionality
		scoreBoard =  new ScoreBoard(gameData, players);
		play();
	}
	
	// This is the constructor for creating a new game
	public Game(String[] playerNames) {
		players = new Player[playerNames.length];
		for (int i = 0; i < playerNames.length; i++){
			players[i] = new Player(playerNames[i]);
		}
		scoreBoard = new ScoreBoard(players);
		play();
	}
	
	private void play (){
		// Set up the scanner object for a console based app
		userInput = new Scanner(System.in);
		
		System.out.println("");
		System.out.println("Let the Game Begin!");
	
		for (int frame = 1; frame <= 10; frame++) {
			System.out.println("");
			System.out.print("Frame ");
			System.out.print(frame);
			System.out.println(":");
			for (int playerIndex = 0; playerIndex < players.length; playerIndex++){
				playerThrow(playerIndex);				
				if (frame != 10){ // The user has a maximum of 2 throws
					if (pinsKnockedDown != 10){
						playerThrow(playerIndex);
					}
				} else { // The user has a maximum of 3 throws
					int throw1Result = pinsKnockedDown;
					playerThrow(playerIndex);
					if (throw1Result + pinsKnockedDown >= 10){ // The player gets the 3rd throw
						playerThrow(playerIndex);
					}
				}
			}
		}
		System.out.println("");
		System.out.println("Game Over");
	}
	
	private void playerThrow(int playerIndex){
		System.out.println("");
		System.out.print("Enter the number of pins knocked down by ");
		System.out.println(players[playerIndex].name);
		System.out.print(">>> ");
		pinsKnockedDown = userInput.nextInt();
		players[playerIndex].score.update(pinsKnockedDown);
		scoreBoard.printToConsole();
	}

}
