
public class Player {
	String name;
	Score score;

	public Player(String name) {
		// TODO Implement Functionality
		this.name = name;
		score = new Score();
	}
	
	public Player (String name, Score score){
		this.name = name;
		this.score = score;
	}

}
