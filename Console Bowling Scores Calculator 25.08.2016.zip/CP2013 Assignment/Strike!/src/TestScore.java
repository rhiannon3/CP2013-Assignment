import static org.junit.Assert.*;

import org.junit.Test;

public class TestScore {
	// Define the score Object
	Score score;
	
//	// Define the 0 scoring game (Zero)
//	int [] individualThrows0 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//	int [] cumulativeFrameScores0 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//	
//	// Define the 300 scoring game (Perfect, handles triple strike in all frames)
//	int [] individualThrows300 = {10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 10, 10};
//	int [] cumulativeFrameScores300 = {30, 60, 90, 120, 150, 180, 210, 240, 270, 300};
//	
//	// Define the 299 scoring game (handles double strike in frame 10)
//	int [] individualThrows299 = {10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 10, 9};
//	int [] cumulativeFrameScores299 = {30, 60, 90, 120, 150, 180, 210, 240, 270, 299};
//	
//	// Define the 125 scoring game (handles spare in frame 9, double strike in frame 10)
//	int [] individualThrows125 = {2, 5, 10, 0, 5, 1, 0, 0, 3, 0, 5, 5, 10, 0, 7, 3, 3, 7, 10, 10, 0};
//	int [] cumulativeFrameScores125 = {7, 23, 29, 29, 32, 52, 72, 85, 105, 125};
//	
//	// Define the 158 scoring game (handles standard in frame 9, strike in frame 10)
//	int [] individualThrows158 = {0, 10, 10, 0, 10, 0, 10, 0, 1, 4, 5, 5, 10, 0, 2, 7, 3, 0, 10, 2, 4};
//	int [] cumulativeFrameScores158 = {20, 50, 71, 86, 91, 111, 130, 139, 142, 158};
		
	@Test
	public void test() {
	}


	

		
}
