
public class Score {
	// Declare the variables
	public int[] individualThrows;
	public int[] cumulativeFrameScores;
	public int cumulativeScore;
	public boolean isFinalised;
	private int completedFrames;
	private int scoredFrames;
	private int throwsMade;
	private boolean calculateSingleStrikeOfFrame9;

	// Define the conditions
	private String queuedFrameCondition;
	private static final String STANDARD= "Standard";
	private static final String SINGLESTRIKE= "SingleStrike";
	private static final String DOUBLESTRIKE= "DoubleStrike";
	private static final String TRIPLESTRIKE= "TripleStrike";
	private static final String SPARE= "Spare";
	private static final String BONUSTHROW= "BonusThrow";

	public Score (){
		individualThrows = new int[21];
		cumulativeFrameScores = new int[10];
		cumulativeScore = 0;
		completedFrames = 0;
		scoredFrames = 0;
		throwsMade = 0;
		isFinalised = false;
		queuedFrameCondition = STANDARD;
		calculateSingleStrikeOfFrame9 = false;
	}

	public void update(int pinsKnockedDown) {
		// Add pinsKnockedDown to throwsMade
		individualThrows[throwsMade] = pinsKnockedDown;
		throwsMade++;
		// Check if that frame is completed
		if (throwsMade >= 19) {
			// This is the 10th frame special conditions apply
			if (throwsMade == 21){
				// This is the final bonus throw
				completedFrames++;
			} else if (throwsMade ==  20){
				// Check for a strike or spare
				if (individualThrows[18] + individualThrows[19] < 10) {
					// The player does not get the bonus throw
					completedFrames++;
				}
			}		
		} else {
			// Standard conditions apply
			if (pinsKnockedDown == 10 & throwsMade % 2 != 0){// Check if the throw was a strike
				individualThrows[throwsMade] = 0;
				throwsMade++;
				completedFrames++;
			} else if (throwsMade % 2 == 0){// Check if 2 throws were made for that frame
				completedFrames++;
			}
		}
		// Check if the game is finished for the player
		if (completedFrames == 10){
			isFinalised = true;
		}
		checkFrameCanBeScored();
	}

	// Create the method that will check after which throws cumulativeFrameScores 
	// and cumulativeScore need to be calculated
	public void checkFrameCanBeScored(){
		if (throwsMade == 21){
			calculateFrame(BONUSTHROW);
		} else if (throwsMade < 19){
			switch(queuedFrameCondition){
			case STANDARD:
				// Calculate a standard frame after the frame is completed
				if (throwsMade % 2 == 0){// Throw 2 of the most recent frame has been made
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){ // Neither a spare or strike was thrown
						calculateFrame(STANDARD);
						// Note that queuedFrameCondition does not change	
						queuedFrameCondition = STANDARD;
					} else if (individualThrows[throwsMade-2] == 10){ // A strike was thrown
						// Another frame is now required to calculate the score of this frame
						queuedFrameCondition= SINGLESTRIKE;
					} else { // A spare was thrown
						// Another frame is now required to calculate the score of this frame
						queuedFrameCondition = SPARE;
					}
				}			
				break;
			case SPARE:
				// Calculate a spare frame after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A strike was thrown
					calculateFrame(SPARE);
					queuedFrameCondition = SINGLESTRIKE;				
				} else { // Either a standard frame or a spare will be thrown
					calculateFrame(SPARE);
					// If a spare is thrown it will be detected after throw 2 is made
					queuedFrameCondition = STANDARD;				
				}			
				break;
			case SINGLESTRIKE:
				// Calculate a single strike after the next frame is completed
				if (throwsMade % 2 == 0){
					if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){
						// Condition 1: The single strike is followed by a standard frame
						calculateFrame(SINGLESTRIKE);
						queuedFrameCondition = STANDARD;
						calculateFrame(STANDARD);
					} else if (individualThrows[throwsMade-2] == 10){
						// Condition 2: The single strike is followed by another strike
						queuedFrameCondition = DOUBLESTRIKE;
					} else {
						// Condition 3: The single strike is followed by spare
						calculateFrame(SINGLESTRIKE);
						queuedFrameCondition = SPARE;
					}
				}			
				break;
			case DOUBLESTRIKE:
				// Calculate a double strike after the 1st throw of the next frame is completed
				// Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
				if (throwsMade % 2 == 0){ // A triple strike was achieved
					calculateFrame(TRIPLESTRIKE);
					// Note that queuedFrameCondition does not change
					queuedFrameCondition = DOUBLESTRIKE;				
				} else { 
					calculateFrame(DOUBLESTRIKE);
					queuedFrameCondition = SINGLESTRIKE;
				}
				break;
			}
		}
		else {
			// This is the final frame special conditions apply
			if (throwsMade == 19){
				switch(queuedFrameCondition){
				case STANDARD:
					calculateFrame(STANDARD);
					// The STANDARD case can only be followed by a single strike or a standard case
					if (individualThrows[throwsMade -1] == 10){
						queuedFrameCondition = SINGLESTRIKE;
					} else {
						queuedFrameCondition = STANDARD;
					}
					break;
				case SPARE:
					calculateFrame(SPARE);
					// The SPARE case can only be followed by a single strike or a standard case
					if (individualThrows[throwsMade -1] == 10){
						queuedFrameCondition = SINGLESTRIKE;
					} else {
						queuedFrameCondition = STANDARD;
					}
					break;
				case SINGLESTRIKE:
					// THE SINGLESTRIKE can be followed by a standard or double strike
					calculateSingleStrikeOfFrame9 = true;
					if (individualThrows[throwsMade - 1] == 10){
						queuedFrameCondition = DOUBLESTRIKE;
					} else {
						queuedFrameCondition = STANDARD;
					}
					
					break;
				case DOUBLESTRIKE:
					if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
						calculateFrame(TRIPLESTRIKE);
						// Note that queuedFrameCondition does not change
						queuedFrameCondition = DOUBLESTRIKE;				
					} else { 
						calculateFrame(DOUBLESTRIKE);
						queuedFrameCondition = SINGLESTRIKE;
					}
					break;
				}
			} else { // throwsMade == 20
				if (calculateSingleStrikeOfFrame9){
					calculateFrame(SINGLESTRIKE);
				}
				switch(queuedFrameCondition){
				case STANDARD:
					// A Standard may be followed by either be a standard or a spare
					if (individualThrows[18] + individualThrows[19] == 10){
						queuedFrameCondition = SPARE;
					} else {
						calculateFrame(STANDARD);
					}
					break;
				case SINGLESTRIKE:
					if (individualThrows[19] == 10){
						queuedFrameCondition = DOUBLESTRIKE;
					}
					break;
				case DOUBLESTRIKE:
					if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
						calculateFrame(TRIPLESTRIKE);
						// Note that queuedFrameCondition does not change
						queuedFrameCondition = DOUBLESTRIKE;				
					} else { 
						calculateFrame(DOUBLESTRIKE);
						queuedFrameCondition = SINGLESTRIKE;
					}
					break;
				}
			}
		}
	}

	// Create the method that calculates cumulativeScore and cumulativeFrameScores
	public void calculateFrame(String condition){
		int mostRecentThrow = throwsMade - 1;
		switch(condition){
		case STANDARD:
			cumulativeScore += individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
			break;
		case SPARE:
			if (throwsMade % 2 == 0){ // The spare was followed by a strike
				cumulativeScore += 20;
			} else {
				cumulativeScore += 10 + individualThrows[mostRecentThrow];
			}
			break;
		case SINGLESTRIKE:
			cumulativeScore += 10 + individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
			break;
		case DOUBLESTRIKE:
			cumulativeScore += 20 + individualThrows[mostRecentThrow];
			break;
		case TRIPLESTRIKE:
			cumulativeScore += 30;
			break;
		case BONUSTHROW:
			cumulativeScore += individualThrows[18] + individualThrows[19] + individualThrows[20];
			break;
		}
		cumulativeFrameScores[scoredFrames] = cumulativeScore;
		scoredFrames++;
		System.out.print("Scored Frames = ");
		System.out.println(scoredFrames);
	}

	public void printCumulativeFrameScores() {
		String data = "|";
		for (int frame = 1; frame < 10; frame++){// Standard conditions apply
			if (cumulativeFrameScores[frame-1] < 10){
				data += "   ";
				data += cumulativeFrameScores[frame-1];
				data += "   |";
			}else if (cumulativeFrameScores[frame-1] < 100) {
				data += "  ";
				data += cumulativeFrameScores[frame-1];
				data += "   |";
			} else{
				data += "  ";
				data += cumulativeFrameScores[frame-1];
				data += "  |";
			}
		}
		if (cumulativeFrameScores[9] < 10){
			data += "     ";
			data += cumulativeFrameScores[9];
			data += "     |";
		}else if (cumulativeFrameScores[9] < 10) {
			data += "    ";
			data += cumulativeFrameScores[9];
			data += "     |";
		} else {
			data += "    ";
			data += cumulativeFrameScores[9];
			data += "    |";
		}
		System.out.println(data);

	}

	public void printIndividualThrows() {
		String data = "|";
		for (int throwIndex = 0; throwIndex < 18; throwIndex++){
			if (throwIndex % 2 == 0){
				if (individualThrows[throwIndex] == 10){
					data += "   | X |";
					throwIndex++;
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			} else {
				if (individualThrows[throwIndex] + individualThrows[throwIndex-1] == 10){
					data += " / |";
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			}
		}
		for (int throwIndex = 18; throwIndex < 21; throwIndex++){
			if (individualThrows[throwIndex] == 10){
				data += " X |";
			} else if (throwIndex != 18){
				if (individualThrows[throwIndex] != 0 & individualThrows[throwIndex] + individualThrows[throwIndex -1] == 10){
					data += " / |";
				} else {
					data += " ";
					data += individualThrows[throwIndex];
					data += " |";
				}
			} else {
				data += " ";
				data += individualThrows[throwIndex];
				data += " |";
			}
		}
		System.out.println(data);
	}


}
