import java.io.IOException;

public class ScoreBoard {
	Player[] players;
	int maxNameLength;

	// This is the constructor for loading a previous games data
	public ScoreBoard(String gameData, Player[] players) {
		// TODO Auto-generated constructor stub
		this.players = players;

		determineMaxNameLength();
	}


	// This is the constructor for creating a new game 
	public ScoreBoard(Player[] players) {
		// TODO Auto-generated constructor stub
		this.players = players;
		determineMaxNameLength();
	}

	private void determineMaxNameLength() {
		maxNameLength = 0;
		for (int i = 0; i < players.length; i++){
			if (players[i].name.length() > maxNameLength){
				maxNameLength = players[i].name.length();
			}
		}

	}

	public void printToConsole(){
		for (int i = 0; i < players.length; i++){
			tab();
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			tab(); 
			players[i].score.printIndividualThrows();
			System.out.print(players[i].name);
			for (int spaceNumber = players[i].name.length(); spaceNumber < maxNameLength + 3; spaceNumber++){
				System.out.print(" ");
			}
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			tab();
			players[i].score.printCumulativeFrameScores();
			tab();
			System.out.println("+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+");
			System.out.println("");
		}
	}

	private void tab() {
		for (int spaceNumber = 0; spaceNumber < maxNameLength + 3; spaceNumber++){
			System.out.print(" ");
		}		
	}

}
